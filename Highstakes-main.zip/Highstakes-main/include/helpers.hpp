#include "EZ-Template/PID.hpp"

void setintakeSpeed(int intakePower);
void setConveyerSpeed(int conveyerPower);


extern bool MogoAuton;
extern bool Mogo;
void mogoMech();
void autoClamp();
void liftIntake();
void scrapperMech();

void WallstakesAuton();

void colorSorterAuton();
void conveyerRaise();
extern bool colorSorterSwitch;

extern bool conveyerUp;
extern int intakeOn;
extern int conveyerOn;
extern int side;
extern int side1;
extern int wallstakeactive;
extern int wallstakeAuton;  // 0 = off  ; 1 = on
extern int wallstakeManualValue; 

  
extern bool holdBagel;
