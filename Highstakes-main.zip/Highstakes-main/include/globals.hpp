#include "EZ-Template/PID.hpp"
#include "api.h"


extern pros::Motor intake;

extern pros::MotorGroup conveyer;
extern pros::MotorGroup wallstake;
   
extern pros::adi::Pneumatics mogoClamp;
extern pros::adi::Pneumatics liftIntakePiston;
extern pros::adi::Pneumatics scrapper;
extern pros::Vision vision_sensor;
