#include "main.h"
#include "pros/abstract_motor.hpp"
#include "pros/motors.h"



// MOTOR FOR INTAKE

//MOTOR FOR CONVEYER
pros::MotorGroup conveyer({17,-16},pros::v5::MotorGears::green);
pros::MotorGroup wallstake({11,-12},pros::v5::MotorGears::green);

// piston for MOBILE GOAL 
pros::adi:: Pneumatics mogoClamp ('e', false);
// PISTON FOR LIFTING THE INTAKE 
pros::adi::Pneumatics liftIntakePiston('f', false);
// PISTON FOR LIFTING THE SCRAPPER
pros::adi::Pneumatics scrapper('g', false);

pros::Motor intake(13, pros::MotorGears::green);
// PORT OF VISION SENSOR
pros::Vision vision_sensor(21);

