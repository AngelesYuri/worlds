#include "EZ-Template/PID.hpp"
#include "main.h"
#include "pros/motors.h"
#include "pros/rtos.h"
#include "pros/rtos.hpp"



  void setintakeSpeed(int intakePower)
  {
  intake.move(intakePower);
  }

  void setwallstakedegree (int targetDegrees, int velocity)
  {
   wallstake.move_absolute(targetDegrees * 1.666666666666667,velocity );
  }
  void setConveyerSpeed(int conveyerPower)
  {
   conveyer.move(conveyerPower);
  }



bool Mogo = false;
void mogoMech()
{
   if(Mogo == false)
    {
     mogoClamp.extend();
     pros::delay(250);
     Mogo = true;
    }
   else if(Mogo == true)
    {
     mogoClamp.retract();
     pros::delay(250);
     Mogo = false;
    }
 }

 void scrapperMech()
 {
  scrapper.toggle();
  pros::delay(250);
 }

 int side = 2;
 int side1 =1;
 
 bool colorSorterSwitch = false;
 bool holdBagel = true;
 int intakeOn = 0; // 0 = off  1 = on  2 = reverse
 int wallstakeactive = 0; // 0 = off  1 = load  2 = dunk
 int conveyerOn = 0;
 
 int wallstakeAuton =  1;  // 0 = off  ; 1 = on
 int wallstakeManualValue = 0; 
 void WallstakesAuton()
  { 
    while(true)
     {
      // at the start noraml walllsatkeauton is == 1
     if(wallstakeAuton == 1 )
       {
        if(wallstakeactive==1)//B
        {
         setwallstakedegree(110 , 50);
        }
        else if(wallstakeactive==2)//C
        {
         setwallstakedegree(220, 100); 
        }
         else if (wallstakeactive==0) //A
        {
         setwallstakedegree(0, 50);
        }
         else if (wallstakeactive==3)//D
        {
         setwallstakedegree(110, 100);
        }
      }

   
    pros::delay(20); 
    } 
  }
 
 void colorSorterAuton()
  { 
    
    while(true)
    {
   
    if(intakeOn==1)
    {
    setintakeSpeed(127);
    }
    else if(intakeOn==2)
    {
    setintakeSpeed(-127);
    }
    else if (intakeOn==0)
    {
    setintakeSpeed(0);
    }


    if(conveyerOn == 1)
    {
    setConveyerSpeed(127);
    }
    else if(conveyerOn == 2)
    {
    setConveyerSpeed(-127);
    }
    else if(conveyerOn == 0)
    {
    setConveyerSpeed(0);
    }
     
     // side is the color of the bagel you have to color sort 
     pros::vision_object_s_t rtn = vision_sensor.get_by_sig(0, side);
     int xCoord1 = rtn.x_middle_coord;
     int YCoord1 = rtn.y_middle_coord;
     int Height1 = rtn.height;
     int Width1 = rtn.width; 
     int area1 = Height1 * Width1;
     // side 1 is the side you are currently on 
     pros::vision_object_s_t rnn = vision_sensor.get_by_sig(0,side1);
     int xCoord2 = rnn.x_middle_coord;
     int YCoord2 = rnn.y_middle_coord;
     int Height2 = rnn.height;
     int Width2 = rnn.width;
     int area2 = Height2 * Width2; 
     // hold bagel in the middlle of the conveyer for shorter distance of bagel to resume scoring
     
     if (vision_sensor.get_object_count() > 0 && xCoord1 <= 210 && xCoord1 >= 120  && YCoord1 <= 130 && colorSorterSwitch==true && intakeOn == 1)
     {
       pros::delay(100);
       setConveyerSpeed(0);
       pros::delay(20);
       setConveyerSpeed(-127);
       pros::delay(50);
     }
     if(vision_sensor.get_object_count() > 0 && ((xCoord1 <= 210 && xCoord1 >= 120  && YCoord1 <= 130) || (xCoord2 <= 210 && xCoord2 >= 120  && YCoord2 <= 130) ) && holdBagel ==true)
     { 
       //stoping the convyer while letting the intake move 
       conveyerOn = 0;
     }
      
    }
 }

 bool MogoAuton = true;
 void autoClamp()
 {
  pros::Distance distanceSensor(20);
  while(MogoAuton)
  {
    if (Mogo == false && distanceSensor.get() < 10) // change 100 later in mm
    {
        mogoClamp.extend();
        Mogo =  true;
        pros::delay(100);
    }
    pros::delay(20);
  }
 }