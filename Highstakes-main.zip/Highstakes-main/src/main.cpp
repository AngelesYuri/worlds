#include "main.h"
#include "EZ-Template/sdcard.hpp"
#include "lemlib/api.hpp" // IWYU pragma: keep
#include "lemlib/asset.hpp"
#include "lemlib/chassis/chassis.hpp"
#include "lemlib/chassis/trackingWheel.hpp"
#include "pros/adi.hpp"
#include "pros/apix.h"
#include "pros/colors.hpp"
#include "pros/device.hpp"
#include "pros/distance.hpp"
#include "pros/misc.h"
#include "pros/misc.hpp"
#include "helpers.hpp"
#include "globals.hpp"
#include "pros/rtos.hpp"
#include "pros/screen.h"
#include "pros/vision.h"
#include <cstddef>
#include <future>


// controller
pros::Controller controller(pros::E_CONTROLLER_MASTER);

// motor groups
pros::MotorGroup leftMotors({-1,-2,-3,-4},pros::MotorGearset::green); // left motor group - ports 3 (reversed), 4, 5 (reversed)
pros::MotorGroup rightMotors({10,9,8,7}, pros::MotorGearset::green); // right motor group - ports 6, 7, 9 (reversed)


// Inertial Sensor on port 18 
pros::Imu imu(17 );

// tracking wheels
// horizontal tracking wheel encoder. Three-wire port A, B reversed
pros::adi::Encoder horizontalEnc('A','B', true);
// vertical tracking wheel encoder. Three-wire port C, D not reversed
pros::adi::Encoder verticalEnc('C','D', false);
// horizontal tracking wheel. 2.75" d iameter, 5.75" offset, back of the robot (negative)
lemlib::TrackingWheel horizontal1(&horizontalEnc, lemlib::Omniwheel::CUSTOM_2, -2.75);
// vertical tracking wheel. 2.75" diameter, 2.5" offset, left of the robot (negative)
lemlib::TrackingWheel vertical1(&verticalEnc,lemlib::Omniwheel::CUSTOM_2, 0);

// drivetrain settings 
lemlib::Drivetrain drivetrain(&leftMotors, // left motor group
                              &rightMotors, // right motor group
                              11.96, // 10 inch track width
                              lemlib::Omniwheel::CUSTOM_3, // using new 4" omnis
                              309, // drivetrain rpm is 360
                              2 // horizontal drift is 2. If we had traction wheels, it would have been 8
);

// Lateral (linear) motion controller - increase acceleration control
lemlib::ControllerSettings linearController(
                      8,  // Reduce kP to lower aggressive corrections
                      0,   // Keep kI at 0 (integral is rarely needed)
                      0.15,   // Increase kD to slow down movement near the target
                      3,   // Anti-windup
                      1,   // Small error range (inches)
                      100, // Small error timeout (ms)
                      5,   // Large error range (inches)
                      500, // Large error timeout (ms)
                      5  // Reduce max acceleration (smoother start)
);

// Angular (turning) motion controller - increase acceleration control
lemlib::ControllerSettings angularController(
                      /*5,    // Reduce kP from 6 to 5 (less aggressive turning correction)
                      0,    // Keep kI at 0
                      5,    // Reduce kD from 6 to 5 to avoid excessive adjustments
                      3,    // Anti-windup
                      1,    // Small error range (degrees)
                      100,  // Small error timeout (ms)
                      3,    // Large error range (degrees)
                      500,  // Large error timeout (ms)
                      4     // Max acceleration*/
                     
                      3,  // Reduce kP for smoother turning 2
                      0,  // Keep kI at 0
                      21.65,  //16  31 Increase kD to slow down sharp turns 12.5
                      3,
                      1, 
                      100, 
                      3, 
                      500, 
                      4 
);


lemlib::OdomSensors sensors(&vertical1, // vertical tracking wheel
                            nullptr, // vertical tracking wheel 2, set to nullptr as we don't have a second one
                            &horizontal1, // horizontal tracking wheel
                            nullptr, // horizontal tracking wheel 2, set to nullptr as we don't have a second one
                            &imu); // inertial sensor   

/*
lemlib::OdomSensors sensors(nullptr, // vertical tracking wheel
  nullptr, // vertical tracking wheel 2, set to nullptr as we don't have a second one
  nullptr, // horizontal tracking wheel
  nullptr, // horizontal tracking wheel 2, set to nullptr as we don't have a second one
  &imu); // inertial sensor   
*/
                                                       
// Adjust throttle curve for tank drive (stronger response)
lemlib::ExpoDriveCurve throttleCurve(
                      3,   // Joystick deadband
                      8,   // Lower minimum output (from 15 to 8) for **quicker starts**
                      1.06 // Increase expo gain (from 1.03 to 1.06) for **faster acceleration**
);

// Adjust steering curve (tank drive has strong turns)
lemlib::ExpoDriveCurve steerCurve(
                      3,   // Joystick deadband
                      6,   // Increase minimum output (from 5 to 6) for **snappier turning**
                      1.03 // Increase expo gain (from 1.01 to 1.03) for **sharper steering**
);
// create the chassis
lemlib::Chassis chassis(drivetrain, linearController, angularController, sensors, &throttleCurve, &steerCurve);
 
/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
int currentAuton = 7;
bool autonStarted = false;
void autonSelector()
{
  while(autonStarted == false)
  {
    
    switch (currentAuton) {
    case 1:
    pros::lcd::print(4, "%s", "BLUE POSITIVE");
    break;
    case 2:
    pros::lcd::print(4, "%s", "BLUE NEGATIVE");
    break;
    case 3:
    pros::lcd::print(4, "%s", "RED POSITIVE");
    break;
    case 4:
    pros::lcd::print(4, "%s", "RED NEGATIVE");
    break;
    case 5:
    pros::lcd::print(4, "%s", "SKILLS POSITIVE");
    break;
    case 6:
    pros::lcd::print(4, "%s",  "SKILLS NEGATIVE");
    break;
   }
 
    if(controller.get_digital(DIGITAL_R1))
		{
      currentAuton++;
      if(currentAuton ==  7)
      {
        currentAuton = 1;
      }
    }
   if(controller.get_digital(DIGITAL_L1))
		{
      currentAuton--;
      if(currentAuton ==  0)
      {
        currentAuton = 6;
      }
    }
    if(controller.get_digital(DIGITAL_R2) && controller.get_digital(DIGITAL_L2))
    {
      autonomous();
    }
  pros::delay(150);
 
  }
 
}


void printPose() {
  while (true) {
      pros::lcd::print(0, "X: %f", chassis.getPose().x);
      pros::lcd::print(1, "Y: %f", chassis.getPose().y);
      pros::lcd::print(2, "Theta: %f", chassis.getPose().theta);
      pros::delay(100);
  }
}


void initialize() {
     
  pros::lcd::initialize(); // initialize brain screen
  chassis.calibrate(); // calibrate sensors
  // Give it time to calibrate
  
  
  pros::Task printPoseTask(printPose);
        
  wallstake.tare_position();

  pros::Task wallskateTask(WallstakesAuton);
  
  //color sorting initialize 
  vision_sensor.clear_led();
  pros::vision_signature_s_t RED_SIG =
  pros::Vision::signature_from_utility(1, 8193, 9907, 9050, -3071, -1779, -2424, 3.000, 0);
  vision_sensor.set_signature(1, &RED_SIG);
    
  pros::vision_signature_s_t BLUE_SIG =
  pros::Vision::signature_from_utility(2, -6255, -4779, -5517, 7481, 10041, 8761, 3.000, 0);
  vision_sensor.set_signature(2, &BLUE_SIG);  

  pros::Task my_task(colorSorterAuton);

  //leftMotors.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  //rightMotors.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  }

/**
 * Runs while the robot is disabled
 */
void disabled() {}

/**
 * runs after initialize if the robot is connected to field control
 */
void competition_initialize() {}

// get a path used for pure pursuit
// this needs to be put outside a function


/**
 * Runs during auto
 *
 * This is an example autonomous routine which demonstrates a lot of the features LemLib has to offer
 */

void autonomous() 
{
     autonStarted = true;
     switch(currentAuton)
     {
      case 1:
      bluePositive();
      break;
      case 2:
      blueNegative();
      break;
      case 3:
      redPositive();
      break;
      case 4:
      redNegative();
      break;
      case 5:
      positiveSkills();
      break;
      case 6:
      negativeSkills();
      break;
      case 7:
      tryPath();
     }
   
}    


/**
 * Runs in driver control
 */


void opcontrol() {
    // controller
    

    while (true) {
    int leftY = controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
    int rightX = controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_X);
    // move the robot
     chassis.curvature(leftY, rightX);
    /*-------------------------------------------------------------------*/
    if(controller.get_digital(DIGITAL_R1))
		{
			     intakeOn = 1;
           conveyerOn = 1;
	  }
    else if(controller.get_digital(DIGITAL_R2))
		{
            intakeOn = 2;
            conveyerOn = 2;        
		}
		else 
		{
            intakeOn = 0;
            conveyerOn = 0;
		}
    if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_UP)
      && controller.get_digital(pros::E_CONTROLLER_DIGITAL_X))   
    {
    pros::c::controller_rumble(pros::E_CONTROLLER_MASTER, "*.*");
    if(wallstakeAuton ==1)
    {
      wallstakeAuton =0;
    }
    else
     wallstakeAuton = 1;
    }
  
   
   static bool prevRight = false;
   static bool prevDown = false;
   static bool prevLeft = false;
   
   
   bool currRight = controller.get_digital(pros::E_CONTROLLER_DIGITAL_RIGHT);
   bool currDown  = controller.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN);
   bool currLeft  = controller.get_digital(pros::E_CONTROLLER_DIGITAL_LEFT);
   
   if (wallstakeAuton == 1) {

    // LOADING POSITION (RIGHT button pressed)
    if (currRight && !prevRight) {
      wallstakeactive = (wallstakeactive != 1) ? 1 : 0;
    }
  
    // SCORING POSITION (DOWN button pressed)
    if (currDown && !prevDown) {
      if (wallstakeactive == 0 || wallstakeactive == 1)
        wallstakeactive = 2;
      else if (wallstakeactive == 2)
        wallstakeactive = 0;
    }
  
    // CORRECTING POSITION (LEFT button pressed)
    if (currLeft && !prevLeft) {
      wallstakeactive = (wallstakeactive != 3) ? 3 : 0;
    }
  }
  
  // Update button states for next iteration
  prevRight = currRight;
  prevDown = currDown;
  prevLeft = currLeft;


   if (wallstakeAuton == 0) 
    {
      if (wallstakeAuton == 0) {
        static bool prevManualRight = false;
        static bool prevManualDown = false;
      
        static int rightHoldTimer = 0;
        static int downHoldTimer = 0;
      
        bool currManualRight = controller.get_digital(pros::E_CONTROLLER_DIGITAL_RIGHT);
        bool currManualDown  = controller.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN);
      
        // RIGHT button logic (increase)
        if (currManualRight) {
          if (!prevManualRight || rightHoldTimer >= 10) {  // Adjust '10' for repeat speed
            if (wallstakeManualValue < 250)
              wallstakeManualValue += 2;
      
            if (!prevManualRight) rightHoldTimer = 0;  // Reset on first press
          }
          rightHoldTimer++;
        } else {
          rightHoldTimer = 0;
        }
      
        // DOWN button logic (decrease)
        if (currManualDown) {
          if (!prevManualDown || downHoldTimer >= 10) {
            if (wallstakeManualValue > 0)
              wallstakeManualValue -= 2;
      
            if (!prevManualDown) downHoldTimer = 0;
          }
          downHoldTimer++;
        } else {
          downHoldTimer = 0;
        }
      
        prevManualRight = currManualRight;
        prevManualDown = currManualDown;
      }
      
    }
/*-------------------------------------------------------------------*/
 if(controller.get_digital(DIGITAL_L1))
	{
			mogoMech();
	}
/*-------------------------------------------------------------------*/
 if(controller.get_digital(DIGITAL_UP))
  {
            if(colorSorterSwitch == true)
            {
              pros::delay(100);
              colorSorterSwitch = false;
            }
            else{
              pros::delay(100);
              colorSorterSwitch = true;
            }
  }
/*-------------------------------------------------------------------*/
   
/*-------------------------------------------------------------------*/
 if(controller.get_digital(DIGITAL_Y))
  {
      scrapperMech();
  }
/*-------------------------------------------------------------------*/
  pros::delay(25);
  }
  
}
// side 1 = red ,wil be  

ASSET(_123_txt)



void bluePositive()  
{
    //initialize color sorting bs
    side = 1;
    side = 2;
    colorSorterSwitch = true;   
    MogoAuton = false;
}


void blueNegative()
{
    side = 1;
    side = 2;
    colorSorterSwitch = true;
   
    
    chassis.setPose(58, 34 , 90);      
    MogoAuton = false;
}
void redPositive() 
{
   side = 2;
   side1 =1;
   colorSorterSwitch = true;
  
   MogoAuton = false;
}
void redNegative()
{ 
   
}


void positiveSkills()
{
   
}

void negativeSkills()
{
     
}


void tryPath()
{
  side = 1;
  side = 2;
  colorSorterSwitch = true;  
  chassis.setPose(0,-47,270);
  /*
  chassis.turnToHeading(0, 2000);
  chassis.turnToHeading(180, 2000);
  chassis.turnToHeading(0, 2000);
  */
  /*
  chassis.turnToHeading(315, 200);
  chassis.moveToPose(-23, -23, 315, 2000);
  pros::delay(2000);
  chassis.moveToPose(-47.0, -47.244,270, 5000);
  */
  chassis.moveToPose(-47, -47,270,5000);
  chassis.moveToPose(0,-47,270,5000);
  
}